#!/usr/bin/env python3
import json
import sys
from pathlib import Path

REQUIRED = ["id", "severity", "status", "bbox", "title"]
VALID_SEVERITY = {"P1", "P2", "P3"}
VALID_STATUS = {"confirmed", "needs_overlay", "user_marked_no_visible_diff", "safe", "irrelevant"}

def fail(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)

if len(sys.argv) != 2:
    fail("用法：python scripts/validate-issues.py report/issues.json")

path = Path(sys.argv[1])
if not path.exists():
    fail(f"文件不存在：{path}")

data = json.loads(path.read_text(encoding="utf-8"))
issues = data.get("issues", [])
if not isinstance(issues, list):
    fail("issues 必须是数组")

ids = set()
for i, item in enumerate(issues, 1):
    for key in REQUIRED:
        if key not in item:
            fail(f"第 {i} 个问题缺少字段：{key}")
    if item["id"] in ids:
        fail(f"重复问题 ID：{item['id']}")
    ids.add(item["id"])
    if item["severity"] not in VALID_SEVERITY:
        fail(f"{item['id']} severity 非法：{item['severity']}")
    if item["status"] not in VALID_STATUS:
        fail(f"{item['id']} status 非法：{item['status']}")
    bbox = item["bbox"]
    if not (isinstance(bbox, list) and len(bbox) == 4 and all(isinstance(x, (int, float)) for x in bbox)):
        fail(f"{item['id']} bbox 必须为 [x, y, width, height]")
    if bbox[2] <= 0 or bbox[3] <= 0:
        fail(f"{item['id']} bbox 宽高必须大于 0")

print(f"OK: {len(issues)} issues validated")
