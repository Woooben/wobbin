#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

parser = argparse.ArgumentParser(description="根据 issues.json 生成全页标注图和局部问题裁图。")
parser.add_argument("--image", required=True, help="实现页面全页截图")
parser.add_argument("--issues", required=True, help="issues.json")
parser.add_argument("--out-dir", required=True, help="输出目录，通常为 report/50-report")
args = parser.parse_args()

image_path = Path(args.image)
issues_path = Path(args.issues)
out_dir = Path(args.out_dir)
detail_dir = out_dir / "annotated-details"
out_dir.mkdir(parents=True, exist_ok=True)
detail_dir.mkdir(parents=True, exist_ok=True)

img = Image.open(image_path).convert("RGB")
data = json.loads(issues_path.read_text(encoding="utf-8"))
issues = data.get("issues", [])
user_regions = data.get("user_marked_regions", [])

draw = ImageDraw.Draw(img)
try:
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
    small_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
except Exception:
    font = ImageFont.load_default()
    small_font = ImageFont.load_default()

RED = (220, 38, 38)
ORANGE = (245, 158, 11)
GRAY = (80, 80, 80)
WHITE = (255, 255, 255)


def label(draw, xy, text, color):
    x, y = xy
    bbox = draw.textbbox((x, y), text, font=font)
    pad = 4
    draw.rectangle((bbox[0]-pad, bbox[1]-pad, bbox[2]+pad, bbox[3]+pad), fill=color)
    draw.text((x, y), text, fill=WHITE, font=font)


def clamp_crop(x, y, w, h, img_w, img_h, padding=32):
    left = max(0, int(x - padding))
    top = max(0, int(y - padding))
    right = min(img_w, int(x + w + padding))
    bottom = min(img_h, int(y + h + padding))
    return left, top, right, bottom

# confirmed / needs overlay annotations
for item in issues:
    bbox = item.get("bbox")
    if not bbox or len(bbox) != 4:
        continue
    x, y, w, h = bbox
    status = item.get("status", "confirmed")
    color = RED if status == "confirmed" else ORANGE
    iid = item.get("id", "I?")
    sev = item.get("severity", "")
    title = item.get("title", "")[:18]
    draw.rectangle((x, y, x+w, y+h), outline=color, width=4)
    label(draw, (x, max(0, y-28)), f"{iid} {sev} {title}", color)

    # detail crop for every issue; report can decide which are required by original rule
    crop_box = clamp_crop(x, y, w, h, img.width, img.height)
    crop = Image.open(image_path).convert("RGB").crop(crop_box)
    cd = ImageDraw.Draw(crop)
    lx, ly = int(x - crop_box[0]), int(y - crop_box[1])
    cd.rectangle((lx, ly, lx+w, ly+h), outline=color, width=4)
    label(cd, (lx, max(0, ly-26)), f"{iid} {sev}", color)
    crop.save(detail_dir / f"issue-{iid}.png")

# user marked regions
for item in user_regions:
    bbox = item.get("bbox")
    if not bbox or len(bbox) != 4:
        continue
    x, y, w, h = bbox
    uid = item.get("id", "U?")
    status = item.get("status", "")
    draw.rectangle((x, y, x+w, y+h), outline=GRAY, width=3)
    label(draw, (x, max(0, y-24)), f"{uid} 用户标注 {status}", GRAY)

if not issues:
    label(draw, (24, 24), "未发现已确认问题；已检查模块范围见报告", GRAY)

img.save(out_dir / "annotated-fullpage.png")
print(out_dir / "annotated-fullpage.png")
