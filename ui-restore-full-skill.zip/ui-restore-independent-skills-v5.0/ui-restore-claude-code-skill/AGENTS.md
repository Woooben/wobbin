# Agent 执行约束

## 不可变更原则

本 Skill 是独立场景版本，但必须完整继承原始 `ui-restore-self-check` 的走查要求。

- `checklists/restore-audit.md` 是门禁、扫描顺序和覆盖范围的唯一检查清单。
- 本 Skill 的专项说明只能追加执行方式或专项风险，不得替代、压缩或删除原始清单。
- 所有场景仍按 S1 / S2 / S3 选择流程。
- 必须交付详细全页标注图 `50-report/annotated-fullpage.png`。
- 原子级问题和拥挤小尺寸问题必须交付 `50-report/annotated-details/issue-<ID>.png`。
- 用户提供的红框、箭头、编号或批注区域必须进入最终标注图并分诊。
- 有本地设计参考图时，必须生成叠图和差异图证据；无法生成时记录为 `未覆盖` 并说明原因。
- S1 / S3 必须执行源码风险扫描或手动替代，并定位已确认且有源码的问题。
- 每个模块、重复卡片、原子目标和图标槽位都必须盘点。
- 无需放大即可看见的普通移动端缺陷，默认至少按 P2 判断。
- 任一强制门禁未完成时，不得给出“整体还原较好”等正向全局结论。

## 标注图执行原则

模型可以判断问题和生成 `issues.json`，但标注图必须优先通过脚本生成，避免手绘不稳定。

推荐流程：

```bash
python scripts/validate-issues.py report/issues.json
python scripts/generate-annotations.py --image <实现截图> --issues report/issues.json --out-dir <报告目录>/50-report
```

脚本生成只是执行方式，不改变原始 Skill 对标注图、裁图、叠图、报告和最终回复展示的要求。
