#!/usr/bin/env node

const fs = require("fs");
const path = require("path");

const args = process.argv.slice(2);
if (args.length < 1 || args.includes("--help") || args.includes("-h")) {
  console.error("用法：node source-risk-scan.js <文件或目录> [--json 输出文件.json] [--summary] [--all] [--limit 数量]");
  process.exit(args.length < 1 ? 1 : 0);
}

const target = path.resolve(args[0]);
const jsonIndex = args.indexOf("--json");
const jsonOut = jsonIndex >= 0 ? args[jsonIndex + 1] : null;
const showSummary = args.includes("--summary");
const showAll = args.includes("--all");
const limitIndex = args.indexOf("--limit");
const perRiskLimit = limitIndex >= 0 ? Math.max(1, Number(args[limitIndex + 1]) || 4) : 4;

const extensions = new Set([
  ".html",
  ".htm",
  ".css",
  ".scss",
  ".less",
  ".js",
  ".jsx",
  ".ts",
  ".tsx",
  ".vue",
  ".svelte",
  ".svg",
]);

const patterns = [
  {
    id: "gradient",
    label: "渐变",
    note: "检查颜色、角度、透明度，以及渐变是局部范围还是错误地覆盖整张卡片。",
    regex: /linear-gradient|radial-gradient/gi,
  },
  {
    id: "zero-height",
    label: "零高度分割线/容器",
    note: "渲染后的分割线或 SVG 可能不可见。",
    regex: /height\s*=\s*["']0["']|height\s*:\s*0(?:px)?\b/gi,
  },
  {
    id: "negative-position",
    label: "负值定位",
    note: "图片、头像或装饰可能泄漏到父容器外。",
    regex: /\b(?:left|right|top|bottom|margin-left|margin-right|margin-top|margin-bottom)\s*:\s*-\d+(?:\.\d+)?px/gi,
  },
  {
    id: "overflow-visible",
    label: "溢出可见",
    note: "父容器可能没有正确裁切图片、头像或内容。",
    regex: /overflow\s*:\s*visible/gi,
  },
  {
    id: "fixed-mobile-width",
    label: "固定移动端宽度",
    note: "实现可能在更窄的移动端视口中溢出。",
    regex: /width\s*:\s*(?:360|375|390|393|414)px\b/gi,
  },
  {
    id: "small-fixed-box",
    label: "小型固定尺寸容器",
    note: "小型固定尺寸容器可能导致文本换行或头像裁切。",
    regex: /width\s*:\s*(?:[1-9]|[1-5]\d|6[0-9])(?:\.\d+)?px[^;\n"']{0,120}height\s*:\s*(?:[1-9]|[1-5]\d|6[0-9])(?:\.\d+)?px/gi,
  },
  {
    id: "svg-viewbox",
    label: "SVG 宽高/viewBox",
    note: "对比渲染宽高与 viewBox，检查被裁切或压缩的徽标和图标。",
    regex: /<svg[^>]*(?:width|height|viewBox)[^>]*>/gi,
  },
  {
    id: "light-svg-foreground",
    label: "浅色 SVG 前景",
    note: "检查渲染后的背景对比度。白色或浅色 SVG 即使存在且加载成功，也可能在白色或浅色背景上消失。",
    regex: /\b(?:fill|stroke)\s*=\s*["'](?:#fff(?:fff)?|white|rgba?\(\s*255\s*,\s*255\s*,\s*255\b)/gi,
  },
  {
    id: "opacity-zero",
    label: "隐藏/透明元素",
    note: "预期的线条或图标可能存在于源码中，但视觉上不可见。",
    regex: /opacity\s*:\s*0\b|fill-opacity\s*=\s*["']0["']|rgba\([^)]*,\s*0\)/gi,
  },
  {
    id: "absolute-z",
    label: "绝对定位/z-index",
    note: "检查重叠、裁切和重复的悬浮图标。",
    regex: /z-index\s*:\s*(?:9{2,}|-?\d{2,})|position\s*:\s*fixed/gi,
  },
  {
    id: "nowrap-missing-hint",
    label: "疑似换行计数器",
    note: "检查固定宽度文本块中的数值或标签是否发生换行。",
    regex: /width\s*:\s*(?:[7-9]\d|1[01]\d|12[0-9])(?:\.\d+)?px[^"'\n]{0,220}(?:次数|数量|剩余|累计|客户|关注|浏览|咨询|带看)/gi,
  },
];

function walk(entry) {
  const stat = fs.statSync(entry);
  if (stat.isFile()) return extensions.has(path.extname(entry)) ? [entry] : [];
  if (!stat.isDirectory()) return [];
  const out = [];
  for (const name of fs.readdirSync(entry)) {
    if (name === "node_modules" || name === ".git" || name === "dist" || name === "build") continue;
    out.push(...walk(path.join(entry, name)));
  }
  return out;
}

function lineNumberForIndex(text, index) {
  let line = 1;
  for (let i = 0; i < index; i += 1) {
    if (text.charCodeAt(i) === 10) line += 1;
  }
  return line;
}

function lineAt(text, lineNumber) {
  return text.split(/\r?\n/)[lineNumber - 1] || "";
}

const files = walk(target);
const findings = [];
const seen = new Set();

function addFinding({ id, risk, note, file, line, snippet }) {
  const key = `${id}:${file}:${line}`;
  if (seen.has(key)) return;
  seen.add(key);
  findings.push({
    id,
    risk,
    note,
    file,
    line,
    snippet: snippet.trim().replace(/\s+/g, " ").slice(0, 220),
  });
}

for (const file of files) {
  const text = fs.readFileSync(file, "utf8");
  for (const pattern of patterns) {
    pattern.regex.lastIndex = 0;
    let match;
    let count = 0;
    while ((match = pattern.regex.exec(text)) && count < 80) {
      count += 1;
      const line = lineNumberForIndex(text, match.index);
      addFinding({
        id: pattern.id,
        risk: pattern.label,
        note: pattern.note,
        file,
        line,
        snippet: lineAt(text, line),
      });
      if (match.index === pattern.regex.lastIndex) pattern.regex.lastIndex += 1;
    }
  }
}

const svgReferences = new Map();
const svgReferenceRegex = /(?:src|href)\s*=\s*["']([^"']+\.svg(?:[?#][^"']*)?)["']|url\(\s*["']?([^"')]+\.svg(?:[?#][^"')]+)?)["']?\s*\)/gi;

for (const file of files) {
  if (path.extname(file).toLowerCase() === ".svg") continue;
  const text = fs.readFileSync(file, "utf8");
  svgReferenceRegex.lastIndex = 0;
  let match;
  while ((match = svgReferenceRegex.exec(text))) {
    const asset = (match[1] || match[2]).replace(/[?#].*$/, "");
    const line = lineNumberForIndex(text, match.index);
    if (!svgReferences.has(asset)) svgReferences.set(asset, []);
    svgReferences.get(asset).push({ file, line, snippet: lineAt(text, line) });
    if (match.index === svgReferenceRegex.lastIndex) svgReferenceRegex.lastIndex += 1;
  }
}

for (const [asset, references] of svgReferences) {
  if (references.length < 2) continue;
  for (const reference of references) {
    addFinding({
      id: "repeated-svg-reference",
      risk: "重复 SVG 素材引用",
      note: `素材 ${asset} 被引用 ${references.length} 次。逐个检查图标槽位的可见性和语义匹配情况。`,
      file: reference.file,
      line: reference.line,
      snippet: reference.snippet,
    });
  }
}

if (jsonOut) fs.writeFileSync(path.resolve(jsonOut), JSON.stringify(findings, null, 2));

const grouped = new Map();
for (const item of findings) {
  if (!grouped.has(item.id)) grouped.set(item.id, []);
  grouped.get(item.id).push(item);
}

if (showSummary) {
  console.log("| 风险组 | 命中数 | 必须执行的视觉检查 |");
  console.log("| --- | ---: | --- |");
  for (const group of grouped.values()) {
    const item = group[0];
    const note = item.id === "repeated-svg-reference"
      ? "存在一个或多个被重复引用的 SVG 素材。按需读取 JSON，并检查受影响图标槽位的语义匹配情况。"
      : item.note;
    console.log(`| ${item.risk} | ${group.length} | ${note.replace(/\|/g, "\\|")} |`);
  }
} else {
  console.log("| 风险 | 文件 | 行号 | 代码片段 | 必须执行的视觉检查 |");
  console.log("| --- | --- | ---: | --- | --- |");
  const printable = [];
  for (const group of grouped.values()) {
    printable.push(...(showAll ? group : group.slice(0, perRiskLimit)));
  }
  for (const item of printable) {
    const rel = path.relative(process.cwd(), item.file) || item.file;
    const snippet = item.snippet.replace(/\|/g, "\\|");
    console.log(`| ${item.risk} | ${rel} | ${item.line} | ${snippet} | ${item.note} |`);
  }
}

if (findings.length === 0) {
  console.log("\n未发现源码风险模式。");
} else {
  console.error(`\n发现 ${findings.length} 条源码风险命中，共 ${grouped.size} 组。`);
  if (showSummary) {
    console.error("当前仅显示摘要。使用 --json 按需查看完整命中。");
  } else if (!showAll) {
    console.error(`每组最多显示 ${perRiskLimit} 条命中。使用 --all 或 --json 查看完整输出。`);
  }
  console.error("将每个风险组分诊为：已确认、安全、待叠图确认或不相关。");
}
