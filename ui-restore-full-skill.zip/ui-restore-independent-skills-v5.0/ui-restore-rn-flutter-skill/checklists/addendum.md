# React Native / Flutter UI 还原走查 Skill专项补充清单

> 本清单只能追加检查项，不得替代 `restore-audit.md`。

## 专项关注

- 适合 React Native、Flutter 等跨端页面。
- 在原始清单基础上补充 iOS/Android 差异、PixelRatio、SafeArea、字体回退、布局约束和组件状态。
- 跨端专项不能替代原始页面 -> 模块 -> 卡片 -> 原子扫描。

## 专项执行

- 分别记录 iOS 与 Android 的设备、系统、DPR/scale、字体缩放和页面状态。
- 检查 SafeArea、状态栏、底部导航、键盘态和长列表底部。
- 检查 RN 样式/Flutter Widget 的宽高、flex/constraint、overflow、文本换行。
- 问题定位到 TSX/JSX/Dart/样式文件和具体组件属性。

## 与原始清单的关系

- 先执行 `restore-audit.md`。
- 再执行本补充清单。
- 如果两者冲突，以 `restore-audit.md` 的强制要求为准。
- 本补充清单中发现的问题，也必须进入原始报告模板的 `已确认问题`、`待叠图确认`、`覆盖门禁` 或 `未覆盖项`。
