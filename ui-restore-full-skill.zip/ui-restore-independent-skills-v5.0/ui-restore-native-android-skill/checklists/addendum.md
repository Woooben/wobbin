# Android Native UI 还原走查 Skill专项补充清单

> 本清单只能追加检查项，不得替代 `restore-audit.md`。

## 专项关注

- 适合 Kotlin / Java / XML / Jetpack Compose 页面。
- 在原始清单基础上补充 status bar、navigation bar、density bucket、fontScale、dp/sp、暗黑模式和资源桶。
- 不能只看单一机型截图；多机型问题需进入适配走查，但仍先执行原始清单。

## 专项执行

- 记录设备、Android 版本、分辨率、density、fontScale、亮/暗模式。
- 检查状态栏/导航栏沉浸、底部系统导航遮挡、dp/sp 使用。
- 检查 mdpi/hdpi/xhdpi/xxhdpi 资源是否模糊、裁切或语义错误。
- 问题定位到 XML/Compose/Kotlin/资源文件和属性。

## 与原始清单的关系

- 先执行 `restore-audit.md`。
- 再执行本补充清单。
- 如果两者冲突，以 `restore-audit.md` 的强制要求为准。
- 本补充清单中发现的问题，也必须进入原始报告模板的 `已确认问题`、`待叠图确认`、`覆盖门禁` 或 `未覆盖项`。
