# Android Native UI 还原走查 Skill

这是一个**独立可用**的 UI 还原走查 Skill。

## 核心原则

本 Skill 完整继承原始 `ui-restore-self-check` 的走查要求，未改变原始 `checklists/restore-audit.md`、`templates/report.md`、`scripts/source-risk-scan.js` 和 `references/project-ui-foundation-template.md`。

## 适用场景

- 适合 Kotlin / Java / XML / Jetpack Compose 页面。
- 在原始清单基础上补充 status bar、navigation bar、density bucket、fontScale、dp/sp、暗黑模式和资源桶。
- 不能只看单一机型截图；多机型问题需进入适配走查，但仍先执行原始清单。

## 使用步骤

1. 准备输入：设计稿、开发截图、代码目录。按照原始 S1/S2/S3 选择场景。
2. 执行 `checklists/restore-audit.md`，先盘点模块、卡片、原子目标和图标槽位。
3. S1/S3 执行源码风险扫描：

```bash
node scripts/source-risk-scan.js <文件或目录> --summary --json report/source-risk.json
```

4. 输出 `report/issues.json`，并校验：

```bash
python scripts/validate-issues.py report/issues.json
```

5. 生成详细标注图：

```bash
python scripts/generate-annotations.py \
  --image <实现截图路径> \
  --issues report/issues.json \
  --out-dir ui-restore-report/50-report
```

6. 使用 `templates/report.md` 补全完整报告。

## 标准输出

```text
ui-restore-report-<page-slug>/
  10-render/
  20-crops/
  30-analysis/
  40-overlays/
  50-report/
    report.md
    annotated-fullpage.png
    annotated-details/
      issue-I1.png
```

## 注意

本 Skill 的专项说明只负责提高在当前工具/开发栈/角色中的执行稳定性，不改变原始走查细节。
