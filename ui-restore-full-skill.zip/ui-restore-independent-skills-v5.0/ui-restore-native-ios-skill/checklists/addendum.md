# iOS Native UI 还原走查 Skill专项补充清单

> 本清单只能追加检查项，不得替代 `restore-audit.md`。

## 专项关注

- 适合 Swift / UIKit / SwiftUI 客户端页面。
- 在原始清单基础上补充 Safe Area、Navigation Bar、Tab Bar、Home Indicator、Dynamic Type、@2x/@3x 资源。
- 客户端专项只追加检查项，不允许弱化原始视觉还原、图标槽位、标注图和覆盖门禁。

## 专项执行

- 记录 iPhone 机型、iOS 版本、scale、字体缩放、亮/暗模式。
- 检查 Safe Area、状态栏、导航栏、底部手势条和吸底按钮。
- 检查系统字体与设计字号/字重、Dynamic Type 放大后的换行和裁切。
- 问题定位到 Swift / xib / storyboard / asset 文件和属性。

## 与原始清单的关系

- 先执行 `restore-audit.md`。
- 再执行本补充清单。
- 如果两者冲突，以 `restore-audit.md` 的强制要求为准。
- 本补充清单中发现的问题，也必须进入原始报告模板的 `已确认问题`、`待叠图确认`、`覆盖门禁` 或 `未覆盖项`。
