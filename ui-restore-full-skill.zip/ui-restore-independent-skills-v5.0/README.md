# UI 还原走查独立 Skill 集 v5.0

本包按照**不同使用工具、不同开发技术栈、设计师走查角色**拆成多个独立 Skill。

## 不变原则

所有独立 Skill 都完整继承原始 `ui-restore-self-check` 的走查要求：

- 原始 `checklists/restore-audit.md` 保持不变；
- 原始 `templates/report.md` 保持不变；
- 原始 `scripts/source-risk-scan.js` 保持不变；
- 原始 `references/project-ui-foundation-template.md` 保持不变；
- 每个独立 Skill 只是追加“工具/开发栈/角色”的执行说明，不替代原始要求。

## Skill 列表

| 类型 | Skill | 适用场景 |
| --- | --- | --- |
| 设计师 | `ui-restore-designer-audit-skill` | 设计师主导走查、截图验收、标注交付 |
| 工具 | `ui-restore-cursor-skill` | Cursor Agent / Composer |
| 工具 | `ui-restore-vscode-codex-skill` | VS Code + Codex，源码定位与修复 |
| 工具 | `ui-restore-claude-code-skill` | Claude Code，大项目长上下文分析 |
| 工具 | `ui-restore-terminal-skill` | Terminal / CLI，脚本化校验和标注 |
| 开发 | `ui-restore-h5-web-skill` | H5 / Web / React / Vue |
| 开发 | `ui-restore-mini-program-skill` | 微信/支付宝等小程序 |
| 开发 | `ui-restore-native-ios-skill` | iOS Native / UIKit / SwiftUI |
| 开发 | `ui-restore-native-android-skill` | Android Native / XML / Compose |
| 开发 | `ui-restore-rn-flutter-skill` | React Native / Flutter |

## 选择建议

- 设计师自己走查：优先使用 `ui-restore-designer-audit-skill`。
- 在 Cursor 中执行：使用 `ui-restore-cursor-skill`。
- 让开发在 VS Code/Codex 中修复：使用 `ui-restore-vscode-codex-skill`。
- 页面是 H5、小程序、iOS、Android、RN/Flutter：使用对应开发栈 Skill。

如果一个场景同时命中“工具”和“开发栈”，优先选择当前执行者真正打开的环境：

- 设计师验收：选设计师 Skill；
- Cursor 里跑全流程：选 Cursor Skill；
- 开发按代码栈自查：选对应开发栈 Skill。

不要同时混用多个 Skill，避免执行上下文过重。每个独立 Skill 都已经包含完整原始走查要求。
