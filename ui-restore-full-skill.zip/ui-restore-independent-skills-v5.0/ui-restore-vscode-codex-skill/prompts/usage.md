# VS Code / Codex UI 还原走查 Skill提示词

```text
使用 ui-restore-vscode-codex 进行 UI 还原走查。

要求不变：必须完整执行 checklists/restore-audit.md，不得简化原始走查要求。

输入：
- 设计稿：<design path>
- 开发截图：<implementation screenshot path>
- 代码目录：<source path，可选>
- 设备/视口/DPR/页面状态：<填写>

执行：
1. 先判断 S1/S2/S3。
2. 按页面 -> 模块 -> 卡片 -> 原子扫描。
3. 盘点可见模块、重复卡片、原子目标和图标槽位。
4. S1/S3 执行源码风险扫描并定位已确认问题。
5. 输出 report/issues.json。
6. 生成 50-report/annotated-fullpage.png 和 annotated-details。
7. 有本地设计参考图时生成叠图和差异图。
8. 使用 templates/report.md 补全报告。
9. 最终回复中直接展示 annotated-fullpage.png，并提供报告和裁图链接。

本轮专项：VS Code / Codex UI 还原走查 Skill。
专项补充只追加检查项，不允许替代原始清单。
```
