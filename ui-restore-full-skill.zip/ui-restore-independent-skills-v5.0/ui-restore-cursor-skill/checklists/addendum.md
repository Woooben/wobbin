# Cursor UI 还原走查 Skill专项补充清单

> 本清单只能追加检查项，不得替代 `restore-audit.md`。

## 专项关注

- 适合在 Cursor Agent / Composer 中执行走查。
- Cursor 不直接手绘标注图，先结构化输出 `report/issues.json`，再调用脚本生成标注图。
- Cursor 的分步执行方式不能替代原始强制交付项，最终仍必须输出完整报告、全页标注图、局部裁图、叠图/差异图记录。

## 专项执行

- 第一轮只识别场景并生成 `report/issues.json`。
- 第二轮运行 `validate-issues.py` 和 `generate-annotations.py`。
- 第三轮基于原始 `templates/report.md` 补全报告和覆盖门禁。
- 修代码时必须基于已确认问题，一次只处理少量问题，修完重新截图复查。

## 与原始清单的关系

- 先执行 `restore-audit.md`。
- 再执行本补充清单。
- 如果两者冲突，以 `restore-audit.md` 的强制要求为准。
- 本补充清单中发现的问题，也必须进入原始报告模板的 `已确认问题`、`待叠图确认`、`覆盖门禁` 或 `未覆盖项`。
